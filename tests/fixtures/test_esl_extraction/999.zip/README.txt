Test ESL submission with mixed encodings
